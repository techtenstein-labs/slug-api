<!-- mcp-name: io.github.techtenstein-labs/techtenstein-slug-mcp -->

# Techtenstein Slug MCP Server

MCP server wrapping the [Techtenstein Slug API](https://slug-api.techtenstein.workers.dev) — Unicode-aware URL slug generator.

## Install

```bash
pip install techtenstein-slug-mcp
```

## Claude Desktop config

```json
{
  "mcpServers": {
    "techtenstein-slug": {
      "command": "techtenstein-slug-mcp"
    }
  }
}
```

## Tool

**slugify** — Convert text to URL-safe slug. Unicode-aware.

Example: `München Straße` → `muenchen-strasse`

Params: `text`, `max`, `sep`, `lower`.

## Sources

- API: https://slug-api.techtenstein.workers.dev
- Custom domain: https://slug.techtenstein.com
